/**
 * The default maximum number of hits to return from
 * either of the autocompletion providers.
 */
export const DefaultMaxHits = 25
